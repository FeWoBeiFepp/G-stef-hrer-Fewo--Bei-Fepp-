# Digitaler Gästeführer „Bei Fepp“

Diese verkleinerte Version kann direkt über die GitHub-Webseite hochgeladen werden.

## Veröffentlichen ohne GitHub Desktop

1. Bei GitHub ein neues Repository erstellen, zum Beispiel `gaestefuehrer-bei-fepp`.
2. Im neuen Repository auf **uploading an existing file** klicken.
3. Die Datei `index.html` und die Datei `.nojekyll` aus diesem Ordner auswählen.
4. Auf **Commit changes** klicken.
5. Danach unter **Settings → Pages** bei **Build and deployment** die Option **Deploy from a branch** wählen.
6. Branch **main** und Ordner **/(root)** wählen, anschließend **Save** anklicken.

## Hinweis

GitHub Pages veröffentlicht die Inhalte öffentlich. Vor dem Hochladen keine Passwörter, Schlüsselhinweise oder anderen privaten Angaben in `index.html` aufnehmen.
